## Minio
Minio basic installation