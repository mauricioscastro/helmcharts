## Kubernetes Image Puller Operator
